
win32 version of yaws

For just running yaws, it works pretty much the same as on UNIX.
Commands that don't work are --id, --heart and some more
Try yaws --help for available options.

Just starting

> yaws -i 

Starts a basic yaws system with a yaws.conf taken from
the install dir.

It's actually possible to develop and edit yaws inside windows. 
Required tools are unxutils and perl installed.


Enjoy,

/klacke

