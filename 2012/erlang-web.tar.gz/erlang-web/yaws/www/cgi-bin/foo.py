#!/usr/bin/python

import cgi

print "Content-type: text/html\n\n"

print "hi there "

